#Abbiamo la variabile: x = 10 Incrementarla di 2 e poi moltiplicarla per 3 Usare due metodi diversi (ad esempio, uno utilizzando gli operatori di assegnazione, e uno senza)
def incrementa_e_moltiplica(x):
    x+=2
    x*=3
    return x
x= 10
x= incrementa_e_moltiplica(x)
print("il valore della variabile è:",x)


