accademy = "Epicode"
print("L'accademy che frequento si chiama:",accademy)