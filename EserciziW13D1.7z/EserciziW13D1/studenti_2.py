#Abbiamo 25 studenti; memorizzare questo dato in una variabile. Arrivano altri 3 studenti; memorizzare questo dato in un'altra variabile.Abbiamo 25 studenti; memorizzare questo dato in una variabile. Arrivano altri 3 studenti; memorizzare questo dato in un'altra variabile.
studenti = 25
studenti_newentry= 3
classe_completa= studenti+studenti_newentry
print("Nella nuova classe ci sono alunni:",classe_completa)