studenti= 25
print("Gli studenti sono:",studenti)