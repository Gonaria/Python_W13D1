#Calcolare e stampare a video quanti secondi ci sono in un anno non bisestile
secondi_in_un_anno = 365 * 24 * 60 * 60
print("Ci sono", secondi_in_un_anno, "secondi in un anno non bisestile")
