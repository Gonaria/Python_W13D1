#Abbiamo la variabile: x = 10 Incrementarla di 2 e poi moltiplicarla per 3 Usare due metodi diversi (ad esempio, uno utilizzando gli operatori di assegnazione, e uno senza)
x=10
y= x+2
z=y*3
print(z)#






