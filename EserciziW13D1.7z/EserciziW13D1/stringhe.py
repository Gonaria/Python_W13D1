#Verificare, per ognuna delle seguenti stringhe, se il numero di caratteri è compreso tra 5 e 8: • str1 = "Windows" • str2 = "Excel" • str3 = "Powerpoint" • str4 = "Word"
str1 = "Windows" ;str2 = "Excel" ;str3 = "Powerpoint"; str4 = "Word"
strings = [str1, str2, str3, str4]
for string in strings: 
    if len(string) >= 5 and len(string) <= 8: 
        print(f"{string}: il numero di caratteri è compreso tra 5 e 8") 
else: 
    print(f"{string}: il numero di caratteri non è compreso tra 5 e 8")
