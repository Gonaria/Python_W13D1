# Esercizio Abbiamo la seguente stringa: my_string = "I am studying Python" • Trasformarla in modo che tutti i caratteri siano maiuscoli (uppercase) • Trasformarla in modo che tutti i caratteri siano minuscoli (lowercase) • Sostituire la sottostringa "Python" con la stringa "a lot" • Usare il metodo .strip(); cambia qualcosa? Perché?
my_string = "I am studying Python"
uppercase_string = my_string.upper() 
print(uppercase_string)
lowercase_string = my_string.lower() 
print(lowercase_string)
replaced_string = my_string.replace("Python", "a lot") 
print(replaced_string)
stripped_string = my_string.strip() 
print(stripped_string)
# il metodo strip non ha cambiato nulla perchè non ci sono spazi nella stringa