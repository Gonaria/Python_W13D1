def fare_spesa():
    lista_spesa =[]
    lista_spesa.append(["latte","pane","frutta","verdura"])
    return lista_spesa
spesa =fare_spesa()
print(spesa)
