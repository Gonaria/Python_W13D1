def workout_palestra_settimana():
    workout = ["spinning","full_body","calisthenic"]
    workout.extend(["punch","yoga"])
    workout_settimana= workout
    return workout_settimana
print(workout_palestra_settimana())

